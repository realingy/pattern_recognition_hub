%							----------------------------------
%							|Copyright : Kopsinis Yannis     |
%							|            Pikrakis Aggelos    |
%							|            Basilas Stratos     |
%							|           -------------------- |
%							|           Dept. of Informatics |
%							|           University of Athens |
%							----------------------------------
%%
function [wt2,bt2]=arx3l

global s1 s2 wt2 bt2 tempwt2 tempbt2

wt2=rand(s2,s1);
bt2=rand(s2,1);
tempwt2=wt2;
tempbt2=bt2;


