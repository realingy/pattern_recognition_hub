%							----------------------------------
%							|Copyright : Kopsinis Yannis     |
%							|            Pikrakis Aggelos    |
%							|            Basilas Stratos     |
%							|           -------------------- |
%							|           Dept. of Informatics |
%							|           University of Athens |
%							----------------------------------
%%
function [wt1,bt1]=arx1hl

global s1 wt1 bt1 metrisis
wt1=rand(s1,size(metrisis,1));
bt1=rand(s1,1);


