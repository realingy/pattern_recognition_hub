%%
global poplr_dec poperr_ratio poplr_inc popmom_const poperr_goal start
global pop_lr popmax_epoch exambles bptmenu arx flayer3 slayer3 at
global flayertxt slayertxt



%FOR THE SVM (SMOMENU) FILE

global popmax_step pop_tol popker_par popreg_factor popkernel_type popker_par_2 popepsilon